import paho.mqtt.client as paho 
import sys
import base64

client = paho.Client()

image : bytes 

with open("./img.jpeg", "rb") as f:
    image = f.read()


message = base64.b64encode(image).decode("ascii")


if client.connect("localhost", 1883, 60) != 0:
    print("couldn't connect to MQQT broker")
    sys.exit(-1)

client.publish("test/status", message)

client.disconnect()


